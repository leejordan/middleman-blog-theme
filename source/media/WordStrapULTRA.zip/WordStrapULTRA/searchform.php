<form action="<?php echo home_url( '/' ); ?>" class="form-inline" id="searchform" method="get" role="search">
    <div class="input-append">
        <input class="span3" type="text" id="s" name="s" value="" placeholder="Search...">
        <input class="btn" type="submit" value="Go!" id="searchsubmit">
    </div>
</form>