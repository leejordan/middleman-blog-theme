<?php get_header(); ?>

    <script type="text/javascript">
        jQuery().ready(function() {
             jQuery('.carousel').carousel({
                 interval: 6000
             });
        });
    </script>  

	<!-- Optional headers on home page -->
    <!--h1><?php bloginfo( 'name' ); ?></h1-->
    <!--h2><?php bloginfo( 'description' ); ?></h2-->

    <!-- Carousel of the 3 most recent posts that have featured images and are not sticky -->
    <?php if(is_home() && !is_paged()) : ?>  

        <?php 
            $carousel_count = 0;
            $carousel_posts = new WP_Query(array($query)); 
            if ($carousel_posts->post_count > 2) : ?>

        <div id="index_carousel" class="carousel">
            <div class="carousel-inner">

            <?php while ($carousel_posts->have_posts() && $carousel_count < 3 ) : $carousel_posts->the_post();
                if ( is_sticky() ) { continue; }
                if(has_post_thumbnail()) : ?>
                    <div class="item <?php if(!$carousel_count) { echo 'active'; } ?>">
                        <?php $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "large" )?>
                        <img src="<?php echo $thumbnail[0] ?>"/>
                        <div class="carousel-caption">
                            <h3><?php the_title(); ?></h3>
                            <?php the_excerpt(); ?>
                        </div>
                    </div>
        <?php   $carousel_count++;
                endif; 
            endwhile; ?>

            </div>
            <a class="left carousel-control" data-slide="prev" href="#index_carousel">&laquo;</a>  
            <a class="right carousel-control" data-slide="next" href="#index_carousel">&raquo;</a>  
        </div>

        <?php endif ?>

    <?php endif ?>

	<?php get_template_part( 'loop', 'index' ); ?>   
    
<?php get_footer(); ?>