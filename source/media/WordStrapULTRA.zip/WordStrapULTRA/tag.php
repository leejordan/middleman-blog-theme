<?php
/**
 * The template for displaying Tag Archive pages.
 *
 */

get_header(); ?>
	<div class="page-header">
		<h1><?php printf( __( 'Tagged: %s', 'twentyten' ), '' . single_tag_title( '', false ) . '' ); ?></h1>
	</div>
	<?php
	/* Run the loop for the search to output the results.
	 * If you want to overload this in a child theme then include a file
	 * called loop-search.php and that will be used instead.
	 */
	 get_template_part( 'loop', 'tag' );
	?>

<?php get_footer(); ?>