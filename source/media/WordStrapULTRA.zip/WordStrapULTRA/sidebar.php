<?php
/**
 * The Sidebar containing the primary and secondary widget areas.
 */
?>
    <ul class="unstyled">
	   <?php dynamic_sidebar( 'primary-widget-area' ); ?>
    </ul>