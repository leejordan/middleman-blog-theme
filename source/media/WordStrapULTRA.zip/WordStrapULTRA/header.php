<?php
/**
 * The Header for our theme.
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php wp_title( '|', true, 'right' ); ?><?php bloginfo('name'); ?></title>
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    <link rel="shortcut icon" href="<?php bloginfo('stylesheet_directory'); ?>/favicon.ico" />
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> onload="prettyPrint();" >

    <div class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar">
                    <span class="icon-chevron-down icon-white"></span>
                </a>
                <a class="brand" href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
                <div class="nav-collapse">
                    <?php wp_nav_menu( 
                        array(
                            'theme_location' => 'nav',
                            'menu' => 'nav',
                            'menu_class' => 'nav', 
                            'container' => 'false'
                        )
                    ); ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="row">
        <?php if ( get_header_image() ) : ?>
            <img class="span12 banner" src="<?php header_image(); ?>" width="<?php echo HEADER_IMAGE_WIDTH; ?>" height="<?php echo HEADER_IMAGE_HEIGHT; ?>" alt="<?php bloginfo( 'name' ); ?> header" />
        <?php endif; ?>
            <div class="span8">
    
