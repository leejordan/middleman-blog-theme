    </div>
    <div class="span4">
        <div class="well sidebar-nav">
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>

<?php get_sidebar( 'footer' ); ?>

<?php
	/* Always have wp_footer() just before the closing </body>
	 * tag of your theme, or you will break many plugins, which
	 * generally use this hook to reference JavaScript files.
	 */

	wp_footer();
?>

</body>
</html>