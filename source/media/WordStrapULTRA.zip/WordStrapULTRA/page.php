<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the wordpress construct of pages
 * and that other 'pages' on your wordpress site will use a
 * different template.
 *
 */

get_header(); ?>

<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
    <h1 class="post_header"><?php the_title(); ?></h1>
    <div class="featured_image">
        <?php if ( has_post_thumbnail() ) the_post_thumbnail('large'); ?>
    </div>
    <?php the_content(); ?>

	<?php comments_template( '', true ); ?>

<?php endwhile; // end of the loop. ?>

<?php get_footer(); ?>