<?php
/*
Template Name: Full Width Page
*/

get_header(); ?>

</div>
<div class="span12">

<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
    <h1 class="post_header"><?php the_title(); ?></h1>
    <div class="featured_image">
        <?php if ( has_post_thumbnail() ) the_post_thumbnail('large'); ?>
    </div>
    <?php the_content(); ?>

	<?php comments_template( '', true ); ?>

<?php endwhile; // end of the loop. ?>

    </div>
</div>

<?php get_sidebar( 'footer' ); ?>

<?php
    /* Always have wp_footer() just before the closing </body>
     * tag of your theme, or you will break many plugins, which
     * generally use this hook to reference JavaScript files.
     */

    wp_footer();
?>

</body>
</html>