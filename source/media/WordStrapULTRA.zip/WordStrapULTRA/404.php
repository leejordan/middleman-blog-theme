<?php get_header(); ?>

	<div class="page-header">
		<h1><?php _e( 'Not Found', 'twentyten' ); ?></h1>
	</div>
	<p><?php _e( 'This page does not exist. Well this page exists obviously, but the one you were looking for does not.', 'twentyten' ); ?></p>

<?php get_footer(); ?>