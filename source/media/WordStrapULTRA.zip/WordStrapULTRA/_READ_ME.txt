
    WordStrap ULTRA v1.0

    - - - - - - - - - - - - - - - - - - - - - - -

    Lots of people have made wordpress themes which are based on bootstrap. Some of them have also chosen to name their themes "WordStrap" but nobody in the history of civilization has thought of adding the word "ULTRA" to the end, to make their theme sound EDGY and EXCITING. I present to you WordStrap ULTRA. *drum roll*

    - - - - - - - - - - - - - - - - - - - - - - -

    About this theme

    - - - - - - - - - - - - - - - - - - - - - - -

    This is a simple wordpress theme where every commonly used wordpress feature has been tweaked to use bootstrap. I started with the barebones starkers theme, I added the responsive bootstrap css and javascript libraries, then I went through every part of the theme applying bootstrap styles where appropriate.

    What this means is that although you can use this theme as it is, it is also a perfect framework to start building your own theme on top of. This is all due to the flexibility of bootstrap as a css framework.

    Included in this theme is all the bootstrap css and javascript (even though it is not all used) and the google code prettify libraries. It also has Modernizr which means any html5 code you require will work in older browsers.

    As the theme is offered for free, it’s also offered without support.

    A live demo can be found here: http://www.lendmeyourear.net/WordStrapULTRA/

    Features:
    * HTML5 support in all browsers
    * Fully responsive, works on all screen sizes and devices
    * Image carousel on home page
    * Sticky posts
    * Full width page template
    * Contact form page template
    * Pagination
    * Nested comments
    * Comment pagination
    * Gallery
    * Featured image use
    * stylish code snippets with google code prettifier

    - - - - - - - - - - - - - - - - - - - - - - -

    How to use this theme

    - - - - - - - - - - - - - - - - - - - - - - -

    1) Install wordpress http://codex.wordpress.org/Installing_WordPress
    2) Download and install this theme - simply download the latest version, unzip the file, upload it to your ‘themes’ directory, and then activate it through your WP admin panel
    3) (optional) Replace or remove the theme header in Appearance > Header in your wordpress admin section
    4) (optional) Create a menu for the top navigation bar called "nav" in Appearance > Menus
    5) (optional) Add your navigation widgets for the sidebar and footer in Appearance > Widgets
    6) If you wish to use the contact form page template, be sure to edit mail.php and put your email address in place of "CHANGE@YOURADDRESS.COM"
    7) If you wish to use featured images as in the demo they should all be 770 pixels wide, and should all have the same height

    - - - - - - - - - - - - - - - - - - - - - - -

    Credits

    - - - - - - - - - - - - - - - - - - - - - - -

    Built by:
    Lee Jordan - http://lendmeyourear.net

    With thanks to:
    Starkers  - http://viewportindustries.com/products/starkers/
    Google    - http://code.google.com/p/google-code-prettify/
    Bootstrap - http://twitter.github.com/bootstrap/
    Modernizr - http://modernizr.com/
    Wordpress - http://wordpress.org/

    - - - - - - - - - - - - - - - - - - - - - - -

    License

    - - - - - - - - - - - - - - - - - - - - - - -

    Copyright (C) 2012 Lee Jordan

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see http://www.gnu.org/licenses/


