<?php
/**
 * TwentyTen functions and definitions
 *
 * Sets up the theme and provides some helper functions. Some helper functions
 * are used in the theme as custom template tags. Others are attached to action and
 * filter hooks in WordPress to change core functionality.
 *
 * The first function, twentyten_setup(), sets up the theme by registering support
 * for various features in WordPress, such as post thumbnails, navigation menus, and the like.
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development and
 * http://codex.wordpress.org/Child_Themes), you can override certain functions
 * (those wrapped in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before the parent
 * theme's file, so the child theme functions would be used.
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are instead attached
 * to a filter or action hook. The hook can be removed by using remove_action() or
 * remove_filter() and you can attach your own function to the hook.
 *
 * We can remove the parent theme's hook only after it is attached, which means we need to
 * wait until setting up the child theme:
 *
 * <code>
 * add_action( 'after_setup_theme', 'my_child_theme_setup' );
 * function my_child_theme_setup() {
 *     // We are providing our own filter for excerpt_length (or using the unfiltered value)
 *     remove_filter( 'excerpt_length', 'twentyten_excerpt_length' );
 *     ...
 * }
 * </code>
 *
 * For more information on hooks, actions, and filters, see http://codex.wordpress.org/Plugin_API.
 *
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 *
 * Used to set the width of images and content. Should be equal to the width the theme
 * is designed for, generally via the style.css stylesheet.
 */
if ( ! isset( $content_width ) )
    $content_width = 770;

/** Tell WordPress to run twentyten_setup() when the 'after_setup_theme' hook is run. */
add_action( 'after_setup_theme', 'twentyten_setup' );

if ( ! function_exists( 'twentyten_setup' ) ):
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 *
 * To override twentyten_setup() in a child theme, add your own twentyten_setup to your child theme's
 * functions.php file.
 *
 * @uses add_theme_support() To add support for post thumbnails and automatic feed links.
 * @uses register_nav_menus() To add support for navigation menus.
 * @uses add_custom_background() To add support for a custom background.
 * @uses add_editor_style() To style the visual editor.
 * @uses load_theme_textdomain() For translation/localization support.
 * @uses add_custom_image_header() To add support for a custom header.
 * @uses register_default_headers() To register the default custom header images provided with the theme.
 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
 *
 * @since Twenty Ten 1.0
 */
function twentyten_setup() {

    // This theme styles the visual editor with editor-style.css to match the theme style.
    add_editor_style();

    // This theme uses post thumbnails
    add_theme_support( 'post-thumbnails' );
    update_option('thumbnail_size_w', 170);
    update_option('thumbnail_size_h', 170);
    update_option('large_size_w', 770);
    update_option('large_size_h', 450);

    // Add default posts and comments RSS feed links to head
    add_theme_support( 'automatic-feed-links' );

    // Make theme available for translation
    // Translations can be filed in the /languages/ directory
    load_theme_textdomain( 'twentyten', TEMPLATEPATH . '/languages' );

    $locale = get_locale();
    $locale_file = TEMPLATEPATH . "/languages/$locale.php";
    if ( is_readable( $locale_file ) )
        require_once( $locale_file );

    // This theme uses wp_nav_menu() in one location.
    register_nav_menus( array(
        'nav' => __( 'Top Navigation Bar' ),
    ) );

    // This theme allows users to set a custom background
    add_custom_background();

    // Your changeable header business starts here
    define( 'HEADER_TEXTCOLOR', '' );
    // No CSS, just IMG call. The %s is a placeholder for the theme template directory URI.
    define( 'HEADER_IMAGE', '%s/images/headers/path.jpg' );

    // The height and width of your custom header. You can hook into the theme's own filters to change these values.
    // Add a filter to twentyten_header_image_width and twentyten_header_image_height to change these values.
    define( 'HEADER_IMAGE_WIDTH', apply_filters( 'twentyten_header_image_width', 1170 ) );
    define( 'HEADER_IMAGE_HEIGHT', apply_filters( 'twentyten_header_image_height', 200 ) );

    // We'll be using post thumbnails for custom header images on posts and pages.
    // Larger images will be auto-cropped to fit, smaller ones will be ignored. See header.php.
    set_post_thumbnail_size( HEADER_IMAGE_WIDTH, HEADER_IMAGE_HEIGHT, true );

    // Don't support text inside the header image.
    define( 'NO_HEADER_TEXT', true );

    add_custom_image_header( '', '' );

    // ... and thus ends the changeable header business.

    // Default custom headers packaged with the theme. %s is a placeholder for the theme template directory URI.
    register_default_headers( array(
        'berries' => array(
            'url' => '%s/images/headers/default.jpg',
            'thumbnail_url' => '%s/images/headers/default-thumbnail.jpg',
            'description' => __( 'Default', 'twentyten' )
        )
    ) );
}
endif;

// load scripts in wordpress init
function load_scripts() {
   wp_enqueue_script('jquery');
   wp_enqueue_script('bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', 'jquery');
   wp_enqueue_script('prettify', get_template_directory_uri() . '/js/prettify.js', 'jquery');
   wp_enqueue_script('modernizr', get_template_directory_uri() . '/js/modernizr-2.0.6.min.js', 'jquery');
   wp_enqueue_script('validate', get_template_directory_uri() . '/js/jquery.validate.pack.js', 'jquery');
   wp_enqueue_script('contact', get_template_directory_uri() . '/js/contact.js', 'jquery');
}    
add_action('init', 'load_scripts');


/**
 * Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
 *
 * To override this in a child theme, remove the filter and optionally add
 * your own function tied to the wp_page_menu_args filter hook.
 *
 * @since Twenty Ten 1.0
 */
function twentyten_page_menu_args( $args ) {
    $args['show_home'] = true;
    return $args;
}
add_filter( 'wp_page_menu_args', 'twentyten_page_menu_args' );

/**
 * Sets the post excerpt length to 45 characters.
 *
 * To override this length in a child theme, remove the filter and add your own
 * function tied to the excerpt_length filter hook.
 *
 * @since Twenty Ten 1.0
 * @return int
 */
function twentyten_excerpt_length( $length ) {
    return 45;
}
add_filter( 'excerpt_length', 'twentyten_excerpt_length' );

/**
 * Returns a "Continue Reading" link for excerpts
 *
 * @since Twenty Ten 1.0
 * @return string "Continue Reading" link
 */
function twentyten_continue_reading_link() {
    return '<div class="btn-group"> <a class="btn btn-info" href="'. get_permalink() . '">' . __( '<i class="icon-white icon-book"></i> Read more', 'twentyten' ) . '</a></div>';
}

/**
 * Replaces "[...]" (appended to automatically generated excerpts) with an ellipsis and twentyten_continue_reading_link().
 *
 * To override this in a child theme, remove the filter and add your own
 * function tied to the excerpt_more filter hook.
 *
 * @since Twenty Ten 1.0
 * @return string An ellipsis
 */
function twentyten_auto_excerpt_more( $more ) {
    return ' &hellip;' . twentyten_continue_reading_link();
}
add_filter( 'excerpt_more', 'twentyten_auto_excerpt_more' );

/**
 * Adds a pretty "Continue Reading" link to custom post excerpts.
 *
 * To override this link in a child theme, remove the filter and add your own
 * function tied to the get_the_excerpt filter hook.
 *
 * @since Twenty Ten 1.0
 * @return string Excerpt with a pretty "Continue Reading" link
 */
function twentyten_custom_excerpt_more( $output ) {
    if ( has_excerpt() && ! is_attachment() ) {
        $output .= twentyten_continue_reading_link();
    }
    return $output;
}
add_filter( 'get_the_excerpt', 'twentyten_custom_excerpt_more' );

/**
* Change gallery shortcode to output bootstrap style galleries
*/
remove_shortcode('gallery', 'gallery_shortcode');
add_shortcode('gallery', 'gallery_shortcode_bootstrap');

function gallery_shortcode_bootstrap($attr) {
    global $post;

    static $instance = 0;
    $instance++;

    // Allow plugins/themes to override the default gallery template.
    $output = apply_filters('post_gallery', '', $attr);
    if ( $output != '' )
        return $output;

    // We're trusting author input, so let's at least make sure it looks like a valid orderby statement
    if ( isset( $attr['orderby'] ) ) {
        $attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
        if ( !$attr['orderby'] )
            unset( $attr['orderby'] );
    }

    extract(shortcode_atts(array(
        'order'      => 'ASC',
        'orderby'    => 'menu_order ID',
        'id'         => $post->ID,
        'itemtag'    => 'li',
        'icontag'    => 'div',
        'captiontag' => 'p',
        'columns'    => 3,
        'size'       => 'large',
        'include'    => '',
        'exclude'    => ''
    ), $attr));

    $id = intval($id);
    if ( 'RAND' == $order )
        $orderby = 'none';

    if ( !empty($include) ) {
        $include = preg_replace( '/[^0-9,]+/', '', $include );
        $_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

        $attachments = array();
        foreach ( $_attachments as $key => $val ) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    } elseif ( !empty($exclude) ) {
        $exclude = preg_replace( '/[^0-9,]+/', '', $exclude );
        $attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    } else {
        $attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    }

    if ( empty($attachments) )
        return '';

    if ( is_feed() ) {
        $output = "\n";
        foreach ( $attachments as $att_id => $attachment )
            $output .= wp_get_attachment_link($att_id, $size, true) . "\n";
        return $output;
    }

    $itemtag = tag_escape($itemtag);
    $captiontag = tag_escape($captiontag);
    $columns = intval($columns);
    if($columns == 1 || $columns == 2 || $columns == 4 || $columns == 8) {
        $use_span_class = 1;
        $span = 8 / $columns;
    }
    $itemwidth = $columns > 0 ? floor(100/$columns)-4 : 100;

    $selector = "gallery-{$instance}";

    $gallery_style = $gallery_div = '';

    $size_class = sanitize_html_class( $size );
    $gallery_div = "<ul id='$selector' class='thumbnails gallery galleryid-{$id} gallery-columns-{$columns} gallery-size-{$size_class}'>";
    $output = $gallery_div;

    $i = 1;
    foreach ( $attachments as $id => $attachment ) {
        $link = isset($attr['link']) && 'file' == $attr['link'] ? wp_get_attachment_link($id, $size, false, false) : wp_get_attachment_link($id, $size, true, false);
        $output .= $use_span_class ? "<{$itemtag} class='gallery-item span{$span}'>" : "<{$itemtag} class='gallery-item' style='width:{$itemwidth}%'>";
        $output .= "<{$icontag} class='gallery-icon thumbnail'>$link";
        if ( $captiontag && trim($attachment->post_excerpt) ) {
            $output .= "
                <div class=\"caption\"><{$captiontag} class='wp-caption-text gallery-caption'>
                " . wptexturize($attachment->post_excerpt) . "
                </{$captiontag}></div>";
        }
        $output .= "</{$icontag}>";
        $output .= "</{$itemtag}>";
        if($i % $columns == 0){
            $output .= "</ul>" . $gallery_div;
        }
        $i++;
    }

    $output .= "
        </ul>\n";

    return $output;
}

/**
 * Custom bootstrap avatar for comments
*/
add_filter('get_avatar','change_avatar_css');

function change_avatar_css($class) {
    $class = str_replace("class='", "class='img-rounded ", $class) ;
    return $class;
}

if ( ! function_exists( 'twentyten_comment' ) ) :
/**
 * Template for comments and pingbacks.
 *
 * To override this walker in a child theme without modifying the comments template
 * simply create your own twentyten_comment(), and that function will be used instead.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 *
 * @since Twenty Ten 1.0
 */
function twentyten_comment( $comment, $args, $depth ) {
    $GLOBALS['comment'] = $comment;
    switch ( $comment->comment_type ) :
        case '' :
    ?>
    <?php
        $isByAuthor = false;
        if($comment->comment_author_email == get_the_author_email()) {
            $isByAuthor = true;
        }
    ?>
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
        <div id="comment-<?php comment_ID(); ?>" class="row">
            
            <div class="comment-author vcard">
                <ul class="avatar thumbnails pull-left">
                    <li>
                        <?php echo get_avatar( $comment, 50 ); ?>
                    </li>
                </ul>
                <?php if($isByAuthor) { print "<h3 class='author_name'>"; } else { print "<h3 class='fn'>"; } ?>
                <?php printf( __( '%s', 'twentyten' ), sprintf( '%s</h3>', get_comment_author_link() ) ); ?>
                <a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
                    <?php
                        printf( __( '%1$s', 'twentyten' ), '<i class="icon-calendar"></i> ' . get_comment_date('d/m/Y') ); ?></a><?php edit_comment_link( __( '(<i class="icon-edit"></i> Edit)', 'twentyten' ), ' ' );
                    ?>
            </div><!-- .comment-author .vcard -->
            
            <?php if ( $comment->comment_approved == '0' ) : ?>
            <div class="comment-body">
                <em><?php _e( 'Your comment is awaiting moderation.', 'twentyten' ); ?></em>
                <br />
            </div>
            <?php endif; ?>
    
            <div class="comment-body">
                <?php comment_text(); ?>
                <div class="comment-reply-wrap pull-right">
                    <?php comment_reply_link( array_merge( $args, array( reply_text => '<i class="icon-comment"></i> Reply', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
                </div>
            </div>
    
        </div><!-- #comment-##  -->

    <?php
            break;
        case 'pingback'  :
        case 'trackback' :
    ?>
    <li class="post pingback well">
        <p><?php _e( '<i class="icon-share"></i> ', 'twentyten' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __('(<i class="icon-edit"></i> Edit)', 'twentyten'), ' ' ); ?></p>
    <?php
            break;
    endswitch;
}
endif;

/**
 * Register bootstrap style widgetized areas, including one sidebars and four widget-ready columns in the footer.
 *
 * To override twentyten_widgets_init() in a child theme, remove the action hook and add your own
 * function tied to the init hook.
 *
 * @since Twenty Ten 1.0
 * @uses register_sidebar
 */
function twentyten_widgets_init() {
    // Area 1, located in the sidebar.
    register_sidebar( array(
        'name' => __( 'Primary Widget Area', 'twentyten' ),
        'id' => 'primary-widget-area',
        'description' => __( 'The primary widget area', 'twentyten' ),
        'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</li><hr/>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    // Area 2, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'First Footer Widget Area', 'twentyten' ),
        'id' => 'first-footer-widget-area',
        'description' => __( 'The first footer widget area', 'twentyten' ),
        'before_widget' => '<div id="%1$s" class="span3 widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    // Area 3, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'Second Footer Widget Area', 'twentyten' ),
        'id' => 'second-footer-widget-area',
        'description' => __( 'The second footer widget area', 'twentyten' ),
        'before_widget' => '<div id="%1$s" class="span3 widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    // Area 4, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'Third Footer Widget Area', 'twentyten' ),
        'id' => 'third-footer-widget-area',
        'description' => __( 'The third footer widget area', 'twentyten' ),
        'before_widget' => '<div id="%1$s" class="span3 widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    // Area 5, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'Fourth Footer Widget Area', 'twentyten' ),
        'id' => 'fourth-footer-widget-area',
        'description' => __( 'The fourth footer widget area', 'twentyten' ),
        'before_widget' => '<div id="%1$s" class="span3 widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
}
/** Register sidebars by running twentyten_widgets_init() on the widgets_init hook. */
add_action( 'widgets_init', 'twentyten_widgets_init' );

/**
 * Removes the default styles that are packaged with the Recent Comments widget.
 *
 * To override this in a child theme, remove the filter and optionally add your own
 * function tied to the widgets_init action hook.
 *
 * @since Twenty Ten 1.0
 */
function twentyten_remove_recent_comments_style() {
    global $wp_widget_factory;
    remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
}
add_action( 'widgets_init', 'twentyten_remove_recent_comments_style' );

if ( ! function_exists( 'twentyten_posted_on' ) ) :

/**
 * Bootstrap design for the current post's category, date/time and author.
 *
 */
function twentyten_posted_on() {
    $categories = get_the_category();
    printf( __( '<div class="btn-group"> <button class="btn btn-mini disabled"><i class="icon-calendar"></i> %1$s</button> %2$s ', 'twentyten' ),
        sprintf( '%1$s',
            get_the_date('d/m/Y')
        ),
        sprintf( '<a href="%1$s" title="%2$s" class="btn btn-mini"><i class="icon-user"></i> %3$s</a></div>',
            get_author_posts_url( get_the_author_meta( 'ID' ) ),
            sprintf( esc_attr__( 'View all posts by %s', 'twentyten' ), get_the_author() ),
            get_the_author()
        )
    );
    if($categories){
        print "<div class='btn-group'> <button class='btn btn-mini disabled'><i class='icon-folder-open'></i> Category</button>";
        foreach ($categories as $cat) {
            printf ( __( '<a href="%1$s" class="btn btn-mini">%2$s</a> ' ),
                get_category_link( $cat->cat_ID ),
                $cat->cat_name
            );	
        }
		print "</div>";
    }
}
endif;

/**
 * Bootstrap design for the current post's tags.
 *
 */
function add_class_the_tags($html){
    $postid = get_the_ID();
    $html = str_replace('<a','<a class="btn btn-mini"',$html);
    $html = str_replace('">','">',$html);
    return $html;
}
add_filter('the_tags','add_class_the_tags',10,1);

/**
 * Bootstrap pagination
 *
 */
function pagination($pages = '', $range = 2)
{  
     $showitems = ($range * 2)+1;  

     global $paged;
     if(empty($paged)) $paged = 1;

     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }   

     if(1 != $pages)
     {
         echo "<div class=\"pagination\"><ul>";
         
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<li class=\"first\"><a href='".get_pagenum_link(1)."'>&laquo;</a></li>";
         if($paged > 1 && $showitems < $pages) echo "<li class=\"prev\"><a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a></li>";

         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<li class=\"active\"><a href=\"".get_pagenum_link($i)."\">".$i."</a></li>" :"<li><a href=\"".get_pagenum_link($i)."\">".$i."</a></li>";
             }
         }

         if ($paged < $pages && $showitems < $pages) echo "<li class=\"next\"><a href='".get_pagenum_link($paged + 1)."'>&rsaquo;</a></li>";  
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<li class=\"last\"><a href='".get_pagenum_link($pages)."'>&raquo;</a></li>";
                 
         echo "</ul><p class=\"pull-right\"><i class=\"icon-file\"></i> " . $paged . " of " . $pages . "</p></div>";
     }
}

// turn off smart quotes
remove_filter('the_content', 'wptexturize');

// turn off html filtering on author bio
remove_filter('pre_user_description', 'wp_filter_kses');

add_filter( 'comment_form_defaults', 'my_comment_defaults');

//custom bootstrap comment form
function my_comment_defaults($defaults) {
    $req = get_option( 'require_name_email' );
    $aria_req = ( $req ? " aria-required='true'" : '' );
    $user = wp_get_current_user();
 
    $defaults = array(
        'fields'               => array(
        'author' => '<div class="input-prepend"><span class="add-on"><i class="icon-user"></i></span>' . '<input id="author" name="author" placeholder="your name" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></div>',
        'email' => '<div class="input-prepend"><span class="add-on"><i class="icon-envelope"></i></span>' . '<input id="email" name="email" placeholder="email@address.co.uk" type="email" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></div>'
                ),
        'comment_field' => '<div><textarea class="span7" id="comment" name="comment" rows="12" aria-required="true"  placeholder="your comment"></textarea></div>',
 
        'must_log_in'          => '<p class="must-log-in">' .  sprintf( __( 'You must be <a href="%s">logged in</a> to post a comment.' ), wp_login_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
 
        'logged_in_as'         => '<p class="logged-in-as">' . sprintf( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>' ), admin_url( 'profile.php' ), $user->display_name, wp_logout_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
 
        'comment_notes_before' => '<fieldset>',
 
        'comment_notes_after'  => '</fieldset>',
 
        'id_form'              => 'commentform',
 
        'id_submit'            => 'comment_submit',
 
        'title_reply'          => __( 'Leave a Comment' ),
 
        'title_reply_to'       => __( 'Leave a Reply to %s' ),
 
        'cancel_reply_link'    => __( 'Cancel reply' ),
 
        'label_submit'         => __( 'Comment' ),
 
                );
 
    return $defaults;
}

// bootstrap next and previous_image_link
if( !class_exists( 'FTTextImageNavLinks' ) ) {
	class FTTextImageNavLinks {

		//This function calls the previous link if previous image exists
		function ft_previous_image_link() {
			$this->ft_adjacent_image_link(true);
		}
		
		//This function calls the next link if next image exists
		function ft_next_image_link() {
			$this->ft_adjacent_image_link(false);
		}

		//This function grabs all images associated with post, determines if previous and next images exist, and prints links where needed.
		function ft_adjacent_image_link($prev) {
			global $post;
			$post = get_post($post);
			$attachments = array_values(get_children("post_parent=$post->post_parent&post_type=attachment&post_mime_type=image&orderby=menu_order ASC, ID ASC"));

			foreach ( $attachments as $k => $attachment )
				if ( $attachment->ID == $post->ID )
					break;

			$k = $prev ? $k - 1 : $k + 1;

			if ( isset($attachments[$k]) ) 
				echo $this->ft_get_attachment_link($attachments[$k]->ID, true, $prev);
		}
		
		//This function actually builds the link and returns the value to the original function called by the theme.
		function ft_get_attachment_link($id = 0, $permalink = false, $prev) {
			$id = intval($id);
			$_post = & get_post( $id );
		
			if ( ('attachment' != $_post->post_type) || !$url = wp_get_attachment_url($_post->ID) )
				return __('Missing Attachment');
		
			if ( $permalink )
				$url = get_attachment_link($_post->ID);
		
			$post_title = attribute_escape($_post->post_title);
		
			if ($prev == true) {
				return "<a href='$url' class='btn pull-left' title='$post_title'><i class='icon-chevron-left'></i> $post_title</a>";		
			} else {
				return "<a href='$url' class='btn pull-right' title='$post_title'>$post_title <i class='icon-chevron-right'></i></a>";		
			}
		}
  	}
}

if( class_exists('FTTextImageNavLinks') ){
	if( !isset($ftTextImageNavLinks) ) {
		$ftTextImageNavLinks = new FTTextImageNavLinks;
	}
}

if( isset($ftTextImageNavLinks) ){
	
	//echos the previous link
	if( !function_exists('ft_previous_image_link') ) {	
		function ft_previous_image_link(){
			global $ftTextImageNavLinks;
			$ftTextImageNavLinks->ft_previous_image_link();
		}
	}

	//echos the next link
	if( !function_exists('ft_next_image_link') ) {	
		function ft_next_image_link(){
			global $ftTextImageNavLinks;
			$ftTextImageNavLinks->ft_next_image_link();
		}
	}
}