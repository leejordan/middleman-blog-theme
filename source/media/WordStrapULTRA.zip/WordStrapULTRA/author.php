<?php get_header(); ?>

<?php
	/* Queue the first post, that way we know who
	 * the author is when we try to get their name,
	 * URL, description, avatar, etc.
	 *
	 * We reset this later so we can run the loop
	 * properly with a call to rewind_posts().
	 */
	if ( have_posts() )
		the_post();
?>

<?php
// If a user has filled out their description, show a bio on their entries.
if ( get_the_author_meta( 'description' ) ) : ?>
	<div class="page-header">
		<div class="row">
			<div class="span6">
				<h1>
					<?php printf( __( '%s', 'twentyten' ), get_the_author() ); ?>
				</h1>			
					<?php the_author_meta( 'description' ); ?>
				<p>
					<a class="btn" href="mailto:<?php echo get_the_author_meta( 'user_email' ) ?>"><i class="icon-envelope"></i> Email</a>
				</p>
			</div>
			<div class="span2">
				<ul class="thumbnails author-avatar">
				  <li>
				    <div class="img-rounded">
		      			<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'twentyten_author_bio_avatar_size', 170 ) ); ?>
				    </div>
				  </li>
				</ul>
			</div>
		</div>
	</div>
<?php else :?>
	<div class="page-header">
		<h1>
			<?php printf( __( '%s', 'twentyten' ), get_the_author() ); ?>
		</h1>	
	</div>
<?php endif; ?>

<?php
	/* Since we called the_post() above, we need to
	 * rewind the loop back to the beginning that way
	 * we can run the loop properly, in full.
	 */
	rewind_posts();

	/* Run the loop for the author archive page to output the authors posts
	 * If you want to overload this in a child theme then include a file
	 * called loop-author.php and that will be used instead.
	 */
	 get_template_part( 'loop', 'author' );
?>

<?php get_footer(); ?>