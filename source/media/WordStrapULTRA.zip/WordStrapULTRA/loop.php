<?php
/**
 * The loop that displays posts.
 *
 * The loop displays the posts and the post content.  See
 * http://codex.wordpress.org/The_Loop to understand it and
 * http://codex.wordpress.org/Template_Tags to understand
 * the tags used in it.
 *
 * This can be overridden in child themes with loop.php or
 * loop-template.php, where 'template' is the loop context
 * requested by a template. For example, loop-index.php would
 * be used if it exists and we ask for the loop with:
 * <code>get_template_part( 'loop', 'index' );</code>
 *
 */
?>

<?php if(is_home() && !is_paged()) { ?>         
<?php query_posts(array('post__in'=>get_option('sticky_posts'))); ?>
    <?php while (have_posts()) : the_post(); ?>
        <?php if ( !is_sticky() ) { continue; } ?>
    	<div class="row loop sticky">
            <div class="well well-small">
        <?php if ( has_post_thumbnail() ) : ?>
                <?php $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "thumbnail" )?>
                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                    <img src="<?php echo $thumbnail[0] ?>" class="span2 img-rounded index-thumbnail sticky-thumbnail"/>
                </a>
                <div class="span5 excerpt with_thumb">
                    <h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
                    <?php twentyten_posted_on(); ?>
                    <?php the_excerpt(); ?>
                </div>
        <?php else : ?>    
                <div class="span7 excerpt">
                    <h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
                    <?php twentyten_posted_on(); ?>
                    <?php the_excerpt(); ?>
                </div>
        <?php endif; ?>
            <div class="clearfix"></div>
            </div>
        </div>
    <?php endwhile; ?>

<?php wp_reset_query(); ?>
<?php } ?>  

<?php /* If there are no posts to display, such as an empty archive page */ ?>
<?php if ( ! have_posts() ) : ?>
        <h1><?php _e( 'Not Found', 'twentyten' ); ?></h1>
        <p><?php _e( 'Apologies, but no results were found for the request. Perhaps searching will help.', 'twentyten' ); ?></p>

<?php endif; ?>

<?php while ( have_posts() ) : the_post(); ?>
    <?php if ( is_sticky() && is_home() && !is_paged() ) { continue; } ?>
    <div class="row loop">
        <?php if ( has_post_thumbnail() ) : ?>
            <?php $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "thumbnail" )?>
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                <img src="<?php echo $thumbnail[0] ?>" class="span2 img-rounded index-thumbnail"/>
            </a>
            <div class="span6 excerpt with_thumb">
                    <h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
                    <?php twentyten_posted_on(); ?>
                    <?php the_excerpt(); ?>
            </div>
        <?php else : ?>    
            <div class="span8 excerpt">
                    <h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
                    <?php twentyten_posted_on(); ?>
                    <?php the_excerpt(); ?>
            </div>
        <?php endif; ?>
    </div>
    <hr/>
<?php 
    endwhile; 
    pagination(); ?>