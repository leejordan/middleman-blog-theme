<?php get_header(); ?>

<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
    <h1 class="post_header"><?php the_title(); ?></h1>
    <div class="featured_image">
    	<?php if ( has_post_thumbnail() ) the_post_thumbnail('large'); ?>
    </div>
    <?php the_content(); ?>
    <div class="post_info">
    <?php twentyten_posted_on(); ?>
    <?php if( has_tag() ) : ?>
        <?php the_tags('<div class="btn-group"> <button class="btn btn-mini disabled"><i class="icon-tags"></i> Tags:</button>', '', '</div>'); ?>
    <?php endif; ?>
    </div>  
	<?php comments_template( '', true ); ?>

<?php endwhile; // end of the loop. ?>

<?php get_footer(); ?>