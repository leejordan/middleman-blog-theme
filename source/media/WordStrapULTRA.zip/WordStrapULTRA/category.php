<?php get_header(); ?>

	<div class="page-header">
		<h1>
			<?php
				print single_cat_title( '', false ); 
			?>
		</h1>
		<?php
            $category_description = category_description();
            if ( ! empty( $category_description ) )
                echo '<p>' . $category_description . '</p>';
        ?>
	</div>

<?php get_template_part( 'loop', 'category' ); ?>   

<?php get_footer(); ?>