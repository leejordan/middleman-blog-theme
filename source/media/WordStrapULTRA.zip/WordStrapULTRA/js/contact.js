/*
Author: Philip Beel
Author URI: http://theodin.co.uk/
Version: 1.0
*/

jQuery(function() {

	// Get the theme location
	var themeFolder = jQuery("#contact").attr("data-theme");
	var postTo = themeFolder + 'mail.php';

	// Validate contact form on keyup and submit
	jQuery("#contact").validate({

		// Validator to display total errors
		invalidHandler: function(e, validator) {
			var errors = validator.numberOfInvalids();
			if (errors) {
				var message = errors === 1
					? '<i class=\"icon-warning-sign\"></i> You missed 1 field. It has been highlighted below'
					: '<i class=\"icon-warning-sign\"></i> Please complete ' + errors + ' fields.  They have been highlighted below';
				jQuery("div.errormsg span").html(message);
				jQuery("div.alert").show();
			} else {
				jQuery("div.alert").hide();
			}
		},

		// Submit the form to the server 
		submitHandler: function() {

			// Assign the relevent fields
			var fullName = jQuery("#name").val()
			,	emailAddress = jQuery("#email").val()
			,	messageContent = jQuery("#message").val()

			// Hide the error msg and the contact form
			jQuery("div.alert, div.errormsg").hide();

			// Post the message contents
			jQuery.post(postTo, {
				name: fullName, 
				email: emailAddress,
				message: messageContent 
			}, function(data) {
				
				// Hide the fields
				jQuery("#contact").hide();
				jQuery("#processing").show();

				// Check the server response	
			  	if(data.response === 'success') {
			  		jQuery("div.alert").hide();
					// Show a success message
					jQuery(".reponse").append("<i class=\"icon-thumbs-up\"></i> Thank you " + fullName +", your message has been sent.").show();
			  	} else {
					// Sever failed to send the message try again
					var severFailureMessage = "<i class=\"icon-warning-sign\"></i> Your message could not be sent. Please try again.";
					jQuery("div.errormsg span").html(severFailureMessage);
					jQuery("div.errormsg, #contact").show();
			  	}
			  	// Hide the processor
			  	jQuery("#processing").hide();
				return false;		  
			});
 		},

		//specify validation rules for each field
		rules: {
			name: {
				required: true
			},
			email: {
				required: true,
				email: true
			},
			message: {
				required: true,
				minlength: 2
			}
		},
		messages: {
			name: "",
			email: "",
			message: ""
		}
	});

});